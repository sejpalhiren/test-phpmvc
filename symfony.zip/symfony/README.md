URL Pattern to Run Project : serverIP/symfony/home/

## Features

* Custom CORE PHP application framework 
* Follows MVC Pattern
* Follows PSR-4 conventions and coding standard
* .htaccess file added for routing and security purpose

## Note
change `AUTH_HTTP_TOKEN` value with your Git User Account Token
file location: C:\wamp64\www\symfony\vendor\knplabs\github-api\lib\Github\Client.php

Refer (Screenshot-2017-10-24 http localhost.png) for output