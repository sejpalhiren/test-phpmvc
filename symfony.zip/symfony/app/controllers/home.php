<?php

/**
* The default home controller, called when no controller/method has been passed 
* to the application.
*/
class Home extends Controller
{

	public function __construct() 
	{
		
	}

	public function indexAction($params = '') 
	{

		$objClient = new \Github\Client();
		
		//$arrResult = $objClient->api('user')->repositories('symfony'); //To Find specific user repositories
		
		$arrResult = $objClient->api('repo')->find('symfony', array('language' => 'php'));
		
		$this->renderView('home/index', [
			'repositories' => $arrResult['repositories']
		]);
			
	}
	
}

?>