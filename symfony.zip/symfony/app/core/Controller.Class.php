<?php
Class Controller
{
	
	public function __construct() 
	{
		
	}
	protected function setModel( $model ) 
	{

		$model = trim($model);

		require_once '../app/models/' . $model .'.Class.php' ;

		return new $model();
	}
	protected function renderView( $view, $data = [] ) 
	{

		require_once '../app/views/' . $view .'.php' ;

	}

}