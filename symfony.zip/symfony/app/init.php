<?php

require_once '../vendor/autoload.php';

require_once 'core/App.Class.php';

require_once 'core/Controller.Class.php';