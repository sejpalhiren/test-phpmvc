<table border='1'>
	<tbody>
	<tr>
		<th>SR#</th>
		<th>Repository Name</th>
		<th>Description</th>
		<th>URL</th>
	</tr>
	<?php
		if(isset($data['repositories'])) :
			foreach($data['repositories'] as $key=>$value) : ?>
				<tr>
					<td><?= ++$key;?></td>
					<td><?= $value['name'];?></td>
					<td><?= !empty(trim($value['description'])) ? $value['description'] : '-';?></td>
					<td><?= !empty(trim($value['url'])) ? $value['url'] : '-';?></td>
				</tr>
	<?php	
			endforeach; 
		endif;
	?>
	</tbody>
</table>