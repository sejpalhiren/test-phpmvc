<html>
	<head>
		 <img src="https://avatars3.githubusercontent.com/u/143937?v=4" alt="Symfony" height="32" width="32"> 
		<h1>Git Hub - Symfony Repositories List</h1>
	</head>
	<body style='width: 100%;text-align: center;vertical-align: middle;margin: 0px auto;display: inline-block;'>
		<section style=' margin: 0px auto;text-align: center;float: none;display: inline-block;'>
		<?php

			require_once '../app/init.php';

			$app = new App;

		?>
		</section>
	</body>
</html>